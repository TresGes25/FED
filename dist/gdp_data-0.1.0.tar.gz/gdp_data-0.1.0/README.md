# FED
PS1 - Exercise 2

Data from: https://data-explorer.oecd.org/vis?tm=real%20gdp%20by%20country%20annual&pg=0&fs[0]=Frequency%20of%20observation%2C0%7CAnnual%23A%23&fc=Frequency%20of%20observation&snb=30&vw=tb&df[ds]=dsDisseminateFinalDMZ&df[id]=DSD_NAMAIN10%40DF_TABLE1_INCOME&df[ag]=OECD.SDD.NAD&df[vs]=2.0&dq=A.USA%2BGBR%2BCHE%2BBRA%2BJPN%2BCHN%2BDEU...B1GQ....USD_EXC.V..&pd=2000%2C2022&to[TIME_PERIOD]=false
