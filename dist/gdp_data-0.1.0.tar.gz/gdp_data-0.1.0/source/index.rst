.. FED_project documentation master file, created by
   sphinx-quickstart on Tue Nov  4 19:30:25 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

FED_project documentation
=========================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:
